'use strict';

/**
 * navbar variables
 */

const navToggleBtn2 = document.querySelector("[data-nav-toggle-btn]");
const header = document.querySelector("[data-header]");

navToggleBtn2.addEventListener("click", function () {
  header.classList.toggle("active");
});
